//role allocation for users
export const roles = {
    admin: "admin",
    user:"user"
}